"""ICPA core package."""
